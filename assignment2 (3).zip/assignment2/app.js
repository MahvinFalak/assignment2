const express=require('express');
const PORT =9999;
const app =express();
const fs = require('fs');
app.set('view engine','pug');
app.set('views','./views');
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use("/static",express.static("public"));


//define routes
app.get("/",(req,res)=>{
    res.render("first_view");
})

app.get("/contacts",(req,res)=>{
    res.render("contacts");
})

app.get("/about",(req,res)=>{
    res.render("about");
})

app.get("/services",(req,res)=>{
    res.render("services");
})

app.get("/gallery",(req,res)=>{
    res.render("gallery");
})

app.get('/contactUs', (req, res) => {
    try {
        // read contents of the file
        const data = fs.readFileSync('data.txt', 'UTF-8')

        // split the contents by new line
        const lines = data.split(/\r?\n/)
      var arr=[]
        // print all lines

        lines.forEach(line => {
            const li=line.split(/,/)
             arr.push(`{"name":"${li[0]}","email":"${li[1]}", "mobile":"${li[2]}", "city":"${li[3]}","remark":"${li[4]}"}`);
        })
        var result = arr.map(info => JSON.parse(info));
        res.render("contactUs",{result:result})
      } catch (err) {
        console.error(err)
      }
})  
app.post('/contacts', (req, res) => {
        let name = req.body.name;
        let email = req.body.email;
        let mobile = req.body.mobile;
        let city = req.body.city;
        let remark = req.body.remark;

    var data = name + "," + email + "," + mobile + "," + city + "," + remark + "\n";
    if (name != "" && email != "" && city != "" && remark != "") {
        fs.appendFile('data.txt', data, (err) => {
            if (err) throw err
        })
        res.send(`<script>
        alert('Information submited successfully'); 
        window.location.assign('/contactUs')
    </script>`);
    }
    else {
        res.send(`<script>
        alert('Fill All Details'); 
        window.location.assign('/contacts')
    </script>`);
    }
})
// app.post("/contacts",(req,res)=>{
//     let name = req.body.name;
//     let email = req.body.email;
//     let mobile = req.body.mobile;
//     let city = req.body.city;
//     let remark = req.body.remark;
//     let data=(' name: ' + name + '\n email : ' + email + '\n mobile : ' + mobile + '\n city : '+ city + '\n remark : '+ remark);
//     if(!fs.existsSync(`./contacts/${email}`)){
//         fs.mkdirSync(`./contacts/${email}`);
//         fs.writeFileSync(`./contacts/${email}/details.txt`,`${data.toString()}`);
//         res.write('')
//         res.send("thanks for contacting us..");
//     }
//     else{
//         res.send("email already exists");
//     }
// })
app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`server work on ${PORT}`)
})